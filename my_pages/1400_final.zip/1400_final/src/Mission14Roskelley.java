import java.util.*;

public class Mission14Roskelley {

    public static void main (String[] args){

        Scanner in = new Scanner(System.in);
        Random r = new Random();
        int num = r.nextInt(37);//makes a number 0-36
        Roulette spin = new Roulette();//create an instance of the Roulette class

        spin.betOnce(in, num);//creates new instance of roulette

    }
}
