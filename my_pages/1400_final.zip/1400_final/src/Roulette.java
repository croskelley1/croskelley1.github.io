import java.util.Scanner;

//Roulette class for Mission14Roskelley
public class Roulette {

    public void betOnce(Scanner in, int num){

        int bet = 0;//to check if they are betting high or low

        System.out.println("Would you like to bet 1) HIGH? or 2) LOW?");
        bet = in.nextInt();

        //make sure they put a valid bet
        while (bet != 1 && bet != 2){
            System.out.println("Sorry, not a valid option.");
            System.out.println("Would you like to bet 1) HIGH? or 2) LOW?");
            bet = in.nextInt();
        }
        //if they bet high
        if (bet == 1){
            //they win if the number spun is greater/equal to 19
            if(num >= 19){
                System.out.println("The winning number was " + num + ". You win!");
            }
            //and lose if the number is anything less, including 0
            else{
                System.out.println("The winning number was " + num + ". You lose.");
            }
        }
        //if they bet low
        if (bet == 2){
            //they win if the number is less/eqaul to 18 and NOT 0
            if (num <=18 && num != 0) {
                System.out.println("The winning number was " + num + ". You win!");
            }
            //and lose if the number is anything else
            else{
                System.out.println("The winning number was " + num + ". You lose.");
            }
        }

    }

}
